<?php
include 'config.php';
include 'header.php';
$categoriesResult = mysqli_query($conn, "SELECT * FROM category");
$categories = mysqli_fetch_all($categoriesResult, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>                                              
    <meta charset="UTF-8">
    <title>Product List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
</head>
<body>
<div class="container mt-5"> 
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center gap-3">
            <h4 class="mb-0">Product List</h4>
            <form method="GET" class="mb-0">
                <select name="category_id" class="form-select" id="category_id" style="width:160px;">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $row): ?>
                        <option value="<?= $row['id']; ?>"><?= $row['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        <a href="create_product.php" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Add Product
        </a>
    </div>

    <table class="table table-bordered">
        <thead class="table-dark"> 
            <tr>                                                       
                <th>Category</th>                                    
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Product Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="productsTable">
        </tbody>
    </table>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
    $(document).ready(function() {
        
        function get_product(category_id = '') {
            $.ajax({
                url: 'get_product.php',  
                type: 'POST',
                data: { category_id },
                success: function(response) {
                    $('#productsTable').html(response);
                }
            });
        }
        get_product();
        $('#category_id').change(function() {
            var category_id = $(this).val();
            get_product(category_id);
        });
    });
</script>


</script>
</body>
</html>