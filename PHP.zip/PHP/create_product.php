<?php
include 'config.php';
include 'header.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_id   = $_POST["category_id"];
    $product_name  = $_POST["Product_name"];
    $product_price = $_POST["Product_price"];
    $product_description = $_POST["product_description"];

    $sql = "INSERT INTO product (category_id,Product_name,Product_price, product_description) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $category_id, $product_name, $product_price, $product_description);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Product added successfully!');</script>";
        } else {
            echo "<script>alert('Error during insertion: " . mysqli_error($conn) . "');</script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Failed to prepare query: " . mysqli_error($conn) . "');</script>";
    }

    mysqli_close($conn);
}

$categoriesResult = mysqli_query($conn, "SELECT * FROM category");
$categories = mysqli_fetch_all($categoriesResult, MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3 class="mb-4">Add Product</h3>

    <form method="POST" action="">
        <div class="mb-3">
            <label class="form-label">Select Category :</label>
            <select name="category_id" class="form-select" required>
                <option value="">-- Select Category --</option>
                <?php foreach ($categories as $row): ?>
                    <option value="<?= $row['id']; ?>"><?= $row['name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="Product_name" class="form-label">Product Name :</label>
            <input type="text" class="form-control" id="Product_name" name="Product_name" required>
        </div>
        <div class="mb-3">
            <label for="Product_price" class="form-label">Product Price :</label>
            <input type="text" class="form-control" id="Product_price" name="Product_price" required>
        </div>
        <div class="mb-3">
            <label for="product_description" class="form-label">Product Description :</label>
            <input type="text" class="form-control" id="product_description" name="product_description" required>
        </div>
        <button type="submit" class="btn btn-success">Add Product </button>
        <a href="product_list.php" class="btn btn-secondary">View Products</a>
    </form>
</div>
</body>
</html>