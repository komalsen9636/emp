<?php
include 'config.php';
include 'header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $e_id       = $_POST["employee_id"];
    $e_name     = $_POST["name"];
    $e_email    = $_POST["email"];
    $e_number   = $_POST["mobile_number"];
    
    
    $sql = "INSERT INTO employee (employee_id, name, email, mobile_number) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $e_id, $e_name, $e_email, $e_number);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Employee added successfully!');</script>";
        } else {
            echo "<script>alert('Error during insertion: " . mysqli_error($conn) . "');</script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Failed to prepare query: " . mysqli_error($conn) . "');</script>";
    }
}


$sql = "SELECT * FROM employee";
$result = mysqli_query($conn, $sql);
$employees = mysqli_fetch_all($result, MYSQLI_ASSOC);

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Registration Form</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h3 class="text-center mb-4">Employee Registration</h3>
    <form action="create.php" method="POST">
        <div class="form-group">
            <label for="employee_id">Employee Id</label>
            <input type="text" class="form-control" id="employee_id" name="employee_id" required>
        </div>
        <div class="form-group mt-3">
            <label for="name">Employee Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group mt-3">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group mt-3">
            <label for="mobile_number">Mobile Number</label>
            <input type="text" class="form-control" id="mobile_number" name="mobile_number" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Register Employee</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
