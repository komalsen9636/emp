<?php
include 'config.php';


if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid product ID.");
}

$product_id = mysqli_real_escape_string($conn, $_GET['id']);


$deleteQuery = "DELETE FROM product WHERE id = '$product_id'";

if (mysqli_query($conn, $deleteQuery)) {
    header("Location: product_list.php?msg=Product deleted successfully");
    exit;
} else {
    echo "Error deleting product: " . mysqli_error($conn);
}
?>
