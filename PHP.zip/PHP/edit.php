<?php

include 'config.php';

include 'header.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    
    $sql = "SELECT * FROM employee WHERE id = $id";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result); 
    } else {
        echo "Error: " . mysqli_error($conn);
        exit;
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $e_name = $_POST["name"];
    $e_email = $_POST["email"];
    $e_number = $_POST["mobile_number"];

   
    $updateSql = "UPDATE employee SET name = ?, email = ?, mobile_number = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $updateSql);

    if ($stmt) {
       
        mysqli_stmt_bind_param($stmt, "sssi", $e_name, $e_email, $e_number, $id);

       
        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Record updated successfully!'); window.location='index.php';</script>";
        } else {
            echo "<script>alert('Error updating record: " . mysqli_error($conn) . "');</script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Error preparing statement: " . mysqli_error($conn) . "');</script>";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Employee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2>Edit Employee Details</h2>
    <form method="POST" action="">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
        </div>
        <div class="form-group">
            <label for="mobile_number">Mobile Number</label>
            <input type="text" class="form-control" id="mobile_number" name="mobile_number" value="<?php echo htmlspecialchars($row['mobile_number']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>


</body>
</html>
