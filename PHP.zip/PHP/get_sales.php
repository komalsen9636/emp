<?php
include 'config.php';

$sql = "SELECT id, Product_name, Product_price FROM product";
$result = $conn->query($sql);

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id' => $row['id'],
        'name' => $row['Product_name'],
        'price' => $row['Product_price']
    ];
}

echo json_encode($products);
?>