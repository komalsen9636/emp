<?php
include 'config.php';
include 'header.php';


if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid product ID.");
}
$product_id = mysqli_real_escape_string($conn, $_GET['id']);


$productQuery = mysqli_query($conn, "SELECT * FROM product WHERE id = '$product_id'");
$product = mysqli_fetch_assoc($productQuery);

if (!$product) {
    die("Product not found.");
}


$categoriesResult = mysqli_query($conn, "SELECT * FROM category");
$categories = mysqli_fetch_all($categoriesResult, MYSQLI_ASSOC);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

  
    if (empty($category_id) || empty($name) || empty($price) || empty($description)) {
        echo "<p style='color: red;'>All fields are required.</p>";
    } else {
        $updateQuery = "UPDATE products SET 
                        category_id='$category_id', 
                        name='$name', 
                        price='$price', 
                        description='$description' 
                        WHERE id='$product_id'";

        if (mysqli_query($conn, $updateQuery)) {
            header("Location: product_list.php?msg=Product updated successfully");
            exit;
        } else {
            echo "<p style='color: red;'>Error updating product: " . mysqli_error($conn) . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h4>Edit Product</h4>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select" required>
                <?php foreach ($categories as $row): ?>
                    <option value="<?= htmlspecialchars($row['id']); ?>" <?= ($row['id'] == $product['category_id']) ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($row['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Product Name</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name'] ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Product Price</label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($product['price'] ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Product Description</label>
            <textarea name="description" class="form-control" required><?= htmlspecialchars($product['description'] ?? ''); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update Product</button>
        <a href="product_list.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
