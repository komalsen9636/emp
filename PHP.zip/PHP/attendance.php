<?php
include 'config.php';
include 'header.php';

$date = $_POST['attendance_date'] ?? date("Y-m-d");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($_POST['status'] as $emp_id => $status) {
        $status = strtoupper(trim($status));
        if ($status === 'A' || $status === 'P') {
            $sql = "INSERT INTO attendance (employee_id, attendance_date, status) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "sss", $emp_id, $date, $status);
                mysqli_stmt_execute($stmt);
            }
        }
    }

    echo "<script>alert('Attendance submitted successfully!');</script>";
}

$employees = [];
$result = mysqli_query($conn, "SELECT * FROM employee");
if ($result) {
    $employees = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="text-end mb-2">
    <a href="attendance_records.php" class="btn btn-primary">View Records</a>
</div>

<div class="container mt-5">
    <h3 class="text-center mb-4">Employee Attendance</h3>
    
    <form method="POST">
        <div class="mb-3 row justify-content-center">
            <label for="attendance_date" class="col-sm-2 col-form-label text-end">Select Date:</label>
            <div class="col-sm-3">
                <input type="date" id="attendance_date" name="attendance_date" value="<?= $date ?>" class="form-control" required>
            </div>
        </div>

        <table class="table table-bordered table-sm align-middle text-center">
            <thead class="table-dark">
                <tr>
                    <th style="width: .5%;">Sr. No.</th>
                    <th style="width: 2%;">Emp ID</th>
                    <th style="width: 5%;">Name</th>
                    <th style="width: 2%;">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; foreach ($employees as $emp): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= htmlspecialchars($emp['employee_id']) ?></td>
                        <td><?= htmlspecialchars($emp['name']) ?></td>
                        <td>
                            <select name="status[<?= $emp['employee_id'] ?>]" class="form-select form-select-sm text-center" required style="width: 80px; margin: auto;">
                                <option value="">--</option>
                                <option value="P">P</option>
                                <option value="A">A</option>
                            </select>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="text-center">
            <button type="submit" class="btn btn-success">Submit Attendance</button>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>                                                                                      