<?php

include 'config.php';
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Employee Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card:hover {
      transform: scale(1.02);
      transition: 0.3s;
    }
  </style>
</head>
<body>
<div class="container py-5">
  <h1 class="mb-4 text-center">Welcome to the Employee Management System</h1>

  <div class="row g-4">
    <div class="col-md-4">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">Manage Employees</h5>
          <p class="card-text">View, edit or delete employee records.</p>
          <a href="create.php" class="btn btn-primary">Add Employee</a>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">View Product</h5>
          <p class="card-text">Quickly Add a new Product in the system.</p>
          <a href="product_list.php" class="btn btn-success">Add Product</a>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">View Categories</h5>
          <p class="card-text">Quickly Add a new Category in the system.</p>
          <a href="create_category.php" class="btn btn-info">Add Product</a>
        </div>
      </div>
    </div>


    <div class="col-md-4">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">View sales</h5>
          <p class="card-text">Quickly Add new sales</p>
          <a href="sales_list.php" class="btn btn-secondary">Add Sales</a>
        </div>
      </div>
    </div>
  </div>
</div>


</body>
</html>
