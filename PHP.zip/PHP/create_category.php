<?php
include 'config.php'; 
include 'header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name']; 
    $img = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    move_uploaded_file($tmp, "uploads/" . $img);

    $sql = "INSERT INTO categories (image, name) VALUES ('$img', '$name')";
    mysqli_query($conn, $sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Category</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3 class="mb-4">Add Category</h3>

    <form method="POST" action="" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Category Name</label>
            <input type="text" class="form-control" name="name" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Category Image</label>
            <input type="file" class="form-control" name="image" required>
        </div>
        <button type="submit" name="submit" class="btn btn-success">Add Category</button>
        <a href="category_list.php" class="btn btn-secondary">View Categories</a>

    </form>
    <div id="categoryList"></div>
</div>

</body>
</html>