<?php
include 'config.php';
include 'header.php';

$sales_id = $_GET['id'] ?? null;
if (!$sales_id) {
    echo "Invalid request.";
    exit;
}


$invoiceResult = $conn->query("SELECT * FROM sales WHERE id = $sales_id");
if ($invoiceResult->num_rows == 0) {
    echo "Invoice not found.";
    exit;
}
$invoice = $invoiceResult->fetch_assoc();


$productDetails = [];
$detailsResult = $conn->query("SELECT * FROM sales_details WHERE sales_id = $sales_id");
while ($row = $detailsResult->fetch_assoc()) {
    $productDetails[] = $row;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $invoice_number = $_POST["invoice_number"] ?? null;
    $party_name = $_POST["party_name"] ?? null;
    $invoice_date = $_POST["invoice_date"] ?? null;
    $product_ids = $_POST["product_id"] ?? [];
    $product_names = $_POST["product_name"] ?? [];
    $product_prices = $_POST["product_price"] ?? [];
    $product_quantities = $_POST["quantity"] ?? [];
    $totals = $_POST["total"] ?? [];
    $gst = $_POST["gst"] ?? 0;
    $net_total = $_POST["net_total"] ?? 0;

    $gst = floatval($gst);
    $net_total = floatval($net_total);

    $conn->begin_transaction();
    try {
        $updateStmt = $conn->prepare("UPDATE sales SET party_name=?, invoice_date=?, gst=?, net_total=? WHERE id=?");
        $updateStmt->bind_param("ssdsi", $party_name, $invoice_date, $gst, $net_total, $sales_id);
        $updateStmt->execute();
        $updateStmt->close();

        $conn->query("DELETE FROM sales_details WHERE sales_id = $sales_id");

        $itemStmt = $conn->prepare("INSERT INTO sales_details (sales_id, product_name, sell_price, quantity, total) VALUES (?, ?, ?, ?, ?)");
        foreach ($product_ids as $index => $product_id) {
            $product_name = $product_names[$index];
            $sell_price = $product_prices[$index];
            $quantity = $product_quantities[$index];
            $total = $totals[$index];

            $itemStmt->bind_param("isdid", $sales_id, $product_name, $sell_price, $quantity, $total);
            $itemStmt->execute();
        }
        $itemStmt->close();
        $conn->commit();

        header("Location: sales_list.php");
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>alert('Update failed: " . $e->getMessage() . "');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Sale</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>
<div class="container mt-3">
    <div class="card p-4">
        <h2>Edit Sale</h2>
        <form method="POST">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label>Invoice Number</label>
                    <input type="text" name="invoice_number" class="form-control" value="<?= $invoice['invoice_number'] ?>" readonly>
                </div>
                <div class="col-md-4">
                    <label>Party Name</label>
                    <input type="text" name="party_name" class="form-control" value="<?= $invoice['party_name'] ?>" required>
                </div>
                <div class="col-md-4">
                    <label>Invoice Date</label>
                    <input type="date" name="invoice_date" class="form-control" value="<?= $invoice['invoice_date'] ?>" required>
                </div>
            </div>

            <table class="table table-bordered" id="productTable">
                <thead class="table-dark">
                    <tr>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($productDetails as $item): ?>
                    <tr>
                        <td>
                            <select class="form-select product_id" name="product_id[]" required></select>
                            <input type="hidden" class="product_name" name="product_name[]" value="<?= $item['product_name'] ?>">
                        </td>
                        <td><input type="text" class="form-control product_price" name="product_price[]" value="<?= $item['sell_price'] ?>" required></td>
                        <td><input type="number" class="form-control quantity" name="quantity[]" value="<?= $item['quantity'] ?>" min="1" required></td>
                        <td><input type="text" class="form-control total" name="total[]" value="<?= $item['total'] ?>" readonly></td>
                        <td><button type="button" class="btn btn-danger removeProduct">Remove</button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div class="d-flex flex-wrap align-items-center gap-3 mt-4">
                <button type="submit" class="btn btn-success">Update</button>

                <div><strong>Grand Total:</strong> <input type="text" id="grand_total" class="form-control d-inline" readonly style="width:120px;"></div>
                <div><strong>GST %:</strong> <input type="text" name="gst" id="gst" class="form-control d-inline" value="<?= $invoice['gst'] ?>" style="width:100px;"></div>
                <div><strong>GST Amt:</strong> <input type="text" id="GST_Amount" class="form-control d-inline" readonly style="width:120px;"></div>
                <div><strong>Net Total:</strong> <input type="text" name="net_total" id="net_total" class="form-control d-inline" value="<?= $invoice['net_total'] ?>" readonly style="width:120px;"></div>
                <div><button type="button" class="btn btn-primary" id="addProduct">Add Product</button></div>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function () {
    function loadProductsDropdown(dropdown, selectedName = '') {
        $.ajax({
            url: 'get_sales.php',
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                dropdown.html('<option value="">Select Product</option>');
                $.each(data, function (index, product) {
                    let selected = product.name === selectedName ? 'selected' : '';
                    dropdown.append(`<option value="${product.id}" data-price="${product.price}" ${selected}>${product.name}</option>`);
                });
                dropdown.trigger('change'); 
            }
        });
    }

    $('#productTable tbody tr').each(function () {
        let name = $(this).find('.product_name').val();
        loadProductsDropdown($(this).find('.product_id'), name);
    });

    $('#addProduct').click(function () {
        let newRow = `<tr>
            <td>
                <select class="form-select product_id" name="product_id[]" required></select>
                <input type="hidden" class="product_name" name="product_name[]">
            </td>
            <td><input type="text" class="form-control product_price" name="product_price[]" required></td>
            <td><input type="number" class="form-control quantity" name="quantity[]" min="1" required></td>
            <td><input type="text" class="form-control total" name="total[]" readonly></td>
            <td><button type="button" class="btn btn-danger removeProduct">Remove</button></td>
        </tr>`;
        $('#productTable tbody').append(newRow);
        loadProductsDropdown($('#productTable tbody tr:last .product_id'));
    });

    $(document).on('change', '.product_id', function () {
        let selectedProduct = $(this).find(':selected');
let price = selectedProduct.data('price') || 0;
let productName = selectedProduct.text();
let row = $(this).closest('tr');

if (!row.find('.product_price').val()) {
    row.find('.product_price').val(price);
}
row.find('.product_name').val(productName);

    });

    $(document).on('input', '.quantity, .product_price', function () {
        let row = $(this).closest('tr');
        calculateRowTotal(row);
        calculateGrandTotal();
    });

    $(document).on('click', '.removeProduct', function () {
        $(this).closest('tr').remove();
        calculateGrandTotal();
    });

    function calculateRowTotal(row) {
        let price = parseFloat(row.find('.product_price').val()) || 0;
        let quantity = parseInt(row.find('.quantity').val()) || 1;
        let total = price * quantity;
        row.find('.total').val(total.toFixed(2));
    }

    function calculateGrandTotal() {
        let grandTotal = 0;
        $('.total').each(function () {
            grandTotal += parseFloat($(this).val()) || 0;
        });
        $('#grand_total').val(grandTotal.toFixed(2));
        calculateNetTotal();
    }

    function calculateNetTotal() {
        let grandTotal = parseFloat($('#grand_total').val()) || 0;
        let gstPercentage = parseFloat($('#gst').val()) || 0;
        let gstAmount = (grandTotal * gstPercentage) / 100;
        let netTotal = grandTotal + gstAmount;
        $('#GST_Amount').val(gstAmount.toFixed(2));
        $('#net_total').val(netTotal.toFixed(2));
    }

    $('#gst').on('input', function () {
        calculateNetTotal();
    });

    calculateGrandTotal(); 
});
</script>
</body>
</html>
