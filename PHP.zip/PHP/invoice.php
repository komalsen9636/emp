<?php
include 'config.php';
include 'header.php';

$id = $_GET['id'] ?? '';

if (empty($id)) {
    echo "Invalid Invoice ID.";
    exit;
}

$invoiceQuery = $conn->prepare("SELECT s.invoice_number, s.party_name, s.invoice_date, s.gst, s.net_total, SUM(sd.total) as grand_total 
                                FROM sales s
                                LEFT JOIN sales_details sd ON s.id = sd.sales_id
                                WHERE s.id = ?
                                GROUP BY s.id");
$invoiceQuery->bind_param("i", $id);
$invoiceQuery->execute();
$invoiceResult = $invoiceQuery->get_result();
$invoice = $invoiceResult->fetch_assoc();

if (!$invoice) {
    echo "Invoice not found.";
    exit;
}

$productQuery = $conn->prepare("SELECT product_name, sell_price, quantity, total FROM sales_details WHERE sales_id = ?");
$productQuery->bind_param("i", $id);
$productQuery->execute();
$productResult = $productQuery->get_result();

$gst_percent = $invoice['gst'] ?? 0;
$gst_amount = ($invoice['grand_total'] * $gst_percent) / 100;
$net_total = $invoice['net_total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice #<?php echo $invoice['invoice_number']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="card p-4">
        <h3 class="text-center">Invoice</h3>
        <div class="row mb-3">
            <div class="col-md-6">
                <strong>Party Name:</strong> <?php echo htmlspecialchars($invoice['party_name']); ?><br>
                <strong>Invoice Date:</strong> <?php echo date("d-M-Y", strtotime($invoice['invoice_date'])); ?>
            </div>
            <div class="col-md-6 text-end">
                <strong>Company Name:</strong> Theka SRP<br>
                <strong>Invoice No:</strong> <?php echo $invoice['invoice_number']; ?>
            </div>
        </div>

        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Product Name</th>
                    <th>Sell Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($product = $productResult->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                        <td>₹<?php echo number_format($product['sell_price'], 2); ?></td>
                        <td><?php echo $product['quantity']; ?></td>
                        <td>₹<?php echo number_format($product['total'], 2); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <div class="row g-0 justify-content-end">
            <div class="col-md-3">
                <table class="table table-borderless mb-0">
                    <tr>
                        <th>Grand Total:</th>
                        <td>₹<?php echo number_format($invoice['grand_total'], 2); ?></td>
                    </tr>
                    <tr>
                        <th>GST (<?php echo $gst_percent; ?>%):</th>
                        <td>₹<?php echo number_format($gst_amount, 2); ?></td>
                    </tr>
                    <tr>
                        <th>Net Total:</th>
                        <td><strong>₹<?php echo number_format($net_total, 2); ?></strong></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="text-end mt-3">
            <button class="btn btn-primary" onclick="window.print()">Print</button>
            <a href="sales_list.php" class="btn btn-secondary">Back to Sales List</a>
        </div>
    </div>
</div>
</body>
</html>

<?php $conn->close(); ?>
