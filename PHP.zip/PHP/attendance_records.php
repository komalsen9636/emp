<?php
include 'config.php';
include 'header.php';

$date = $_GET['date'] ?? date("Y-m-d");


$sql = "
    SELECT a.employee_id, e.name, a.status, a.attendance_date
    FROM attendance a
    JOIN employee e ON a.employee_id = e.employee_id
    WHERE a.attendance_date = ?
    ORDER BY a.employee_id ASC
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $date);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$records = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $records[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Attendance Records - Filter by Date</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h3 class="text-center mb-4">Attendance Records</h3>

    <div class="row mb-3">
        <div class="col-md-6">
            <form method="GET" class="d-flex">
                <input type="date" name="date" value="<?= htmlspecialchars($date) ?>" class="form-control me-2" required>
                <button type="submit" class="btn btn-primary">Filter</button>
            </form>
        </div>
        <div class="col-md-6 text-end">
            <a href="attendance.php" class="btn btn-success">Mark Attendance</a>
        </div>
    </div>

    <table class="table table-bordered table-hover table-sm text-center">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Employee ID</th>
                <th>Name</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($records)): ?>
                <?php $i = 1; foreach ($records as $row): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= htmlspecialchars($row['employee_id']) ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td><?= htmlspecialchars($row['attendance_date']) ?></td>
                        <td>
                            <a href="attendance_edit.php?id=<?= $row['employee_id'] ?>&date=<?= $row['attendance_date'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No attendance records found for <?= htmlspecialchars($date) ?>.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
