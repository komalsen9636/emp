<?php
include 'config.php';
include 'header.php';


$employee_id = $_GET['id'] ?? '';
$date = $_GET['date'] ?? '';

if (!$employee_id || !$date) {
    echo "<script>alert('Invalid request'); window.location.href='attendance_records.php';</script>";
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = strtoupper(trim($_POST['status']));

    if ($status === 'A' || $status === 'P') {
        $sql = "UPDATE attendance SET status = ? WHERE employee_id = ? AND attendance_date = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sss", $status, $employee_id, $date);
        mysqli_stmt_execute($stmt);

        echo "<script>alert('Attendance updated successfully'); window.location.href='attendance_records.php?date=$date';</script>";
        exit;
    } else {
        $error = "Status must be A or P";
    }
}


$sql = "
    SELECT a.employee_id, e.name, a.status, a.attendance_date
    FROM attendance a
    JOIN employee e ON a.employee_id = e.employee_id
    WHERE a.employee_id = ? AND a.attendance_date = ?
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ss", $employee_id, $date);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$record = mysqli_fetch_assoc($result);

if (!$record) {
    echo "<script>alert('Attendance record not found'); window.location.href='attendance_records.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3 class="text-center mb-4">Edit Attendance</h3>

    <div class="card mx-auto" style="max-width: 500px;">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Employee ID:</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($record['employee_id']) ?>" disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Name:</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($record['name']) ?>" disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Date:</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($record['attendance_date']) ?>" disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Status (A/P):</label>
                    <input type="text" name="status" class="form-control text-uppercase" maxlength="1" pattern="[APap]" required value="<?= htmlspecialchars($record['status']) ?>">
                    <?php if (isset($error)) echo "<small class='text-danger'>$error</small>"; ?>
                </div>

                <div class="d-flex justify-content-between">
                    <a href="attendance_records.php?date=<?= $date ?>" class="btn btn-secondary">Back</a>
                    <button type="submit" class="btn btn-primary">Update Attendance</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
