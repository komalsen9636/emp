<footer>
    <div class="container">
        <p>&copy; <?php echo date("Y"); ?> Employee Management System. All rights reserved.</p>
        <p>Developed by [Your Name]</p>
    </div>
</footer>