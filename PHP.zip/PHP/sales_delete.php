<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    
    $delete_details_sql = "DELETE FROM sales_details WHERE sales_id = $id";
    $conn->query($delete_details_sql);

    $delete_sql = "DELETE FROM sales WHERE id = $id";
    if ($conn->query($delete_sql) === TRUE) {
        header("Location: sales_list.php");
        exit;
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
