<?php
include 'config.php';
include 'header.php';

$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';

$whereClause = "";
$params = [];


if (!empty($from_date) && !empty($to_date)) {
    $whereClause = " WHERE s.invoice_date BETWEEN ? AND ?";
    $params[] = $from_date;
    $params[] = $to_date;
}

$sql = "SELECT s.id, s.invoice_number, s.party_name, s.invoice_date, 
               SUM(sd.total) as grand_total 
        FROM sales s 
        LEFT JOIN sales_details sd ON s.id = sd.sales_id 
        $whereClause
        GROUP BY s.id";


$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param("ss", ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

</head>
<body>
<div class="mb-3">
        <a href="sales.php" class="btn btn-success me-2">Add sale</a>
        </div>
<div class="container mt-5">
    <div class="card p-4">
          
    <h2>Sales List</h2>
    <form method="GET" action="" class="d-flex gap-2 mb-4">
    <input type="text" name="from_date" class="form-control date-picker" 
        value="<?php echo !empty($from_date) ? date('Y-m-d', strtotime($from_date)) : ''; ?>" placeholder="From Date" required>
    
    <input type="text" name="to_date" class="form-control date-picker" 
        value="<?php echo !empty($to_date) ? date('Y-m-d', strtotime($to_date)) : ''; ?>" placeholder="To Date" required>
    
    <button type="submit" class="btn btn-primary">Filter</button>
    <a href="sales_list.php" class="btn btn-danger">Reset</a>
</form>

    <table class="table table-bordered">
            <thead class="table-dark">
            <tr>
                <th>Invoice Number</th>
                <th>Party Name</th>
                <th>Invoice Date</th>
                <th>Grand Total</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
          <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['invoice_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['party_name']); ?></td>
                    
                    <td><?php echo date("d-M-Y", strtotime($row['invoice_date'])); ?></td>
                    <td><?php echo number_format($row['grand_total'], 2); ?></td>
                    <td>
                        <a href="sales_edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="sales_delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                        <a href="invoice.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Print</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
</div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
    $(document).ready(function () {
        $('.date-picker').datepicker({
            format: 'dd-mm-yyyy',
            autoclose: true,
            todayHighlight: true
        });
    });
</script>


</html>
<?php $conn->close(); ?>
