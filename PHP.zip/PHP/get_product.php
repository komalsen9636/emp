<?php
include 'config.php';

$categoryFilter = "";
if (!empty($_POST['category_id'])) {
    $category_id = intval($_POST['category_id']);
    $categoryFilter = "WHERE product.category_id = $category_id";
}

$sql = "SELECT product.*, category.name AS category_name 
        FROM product
        LEFT JOIN category ON product.category_id = category.id 
        $categoryFilter";
$result = mysqli_query($conn, $sql);

if ($result->num_rows > 0): 
    while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= ($row['category_name']); ?></td>
            <td><?= ($row['product_name']); ?></td>
            <td><?= ($row['product_price']); ?></td>
            <td><?= ($row['product_description']); ?></td>
            <td>
                <a href="edit_product.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="delete_product.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-danger"
                   onclick="return confirm('Are you sure to delete?');">Delete</a>
            </td>
        </tr>
    <?php endwhile; 
else: ?>
    <tr><td colspan="5">No products found.</td></tr>
<?php endif; 
?>