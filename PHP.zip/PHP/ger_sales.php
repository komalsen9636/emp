<?php

include 'config.php';


$sql = "SELECT id, Product_name AS name, price FROM product";  
$result = mysqli_query($conn, $sql);


$products = [];


if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        
        $products[] = $row;
    }

   
    echo json_encode($products);
} else {
  
    echo json_encode(["error" => "Failed to fetch products"]);
}


mysqli_close($conn);
?>
